"use client";

import { Song } from "@/types";
import React, { useEffect } from "react";
import MediaItem from "./MediaItem";
import LikeSong from "./LikeSong";
import { useRouter } from "next/navigation";
import { useUser } from "@/hooks/useUser";
import useOnPlay from "@/hooks/useOnPlay";

type LikedContentProps = {
	songs: Song[];
};

const LikedContent: React.FC<LikedContentProps> = ({ songs }) => {
	const onPlay = useOnPlay(songs);
	const router = useRouter();
	const { isLoading, user } = useUser();

	useEffect(() => {
		if (!isLoading && !user) {
			//if user is not loggedin
			router.push("/");
		}
	}, [isLoading, user, router]);

	if (songs.length === 0) {
		return <div className="flex flex-col gap-y-2 w-full px-6 text-neutral-400">No liked songs.</div>;
	}

	return (
		<div className="flex flex-col gap-y-2 w-full p-6">
			{songs.map((song: any) => (
				<div key={song.id} className="flex items-center gap-x-4 w-full">
					<div className="flex-1">
						<MediaItem
							onClick={(id: string) => {
								onPlay(id);
							}}
							song={song}
						/>
					</div>
					<LikeSong songId={song.id} />
				</div>
			))}
		</div>
	);
};

export default LikedContent;
